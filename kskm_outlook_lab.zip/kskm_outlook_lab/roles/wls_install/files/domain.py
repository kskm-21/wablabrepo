from java.io import File
domainDir = File("WABTestDomain")
bool = domainDir.mkdir()
if bool==1:
  print 'Successfully created a new Directory'
else:
  if domainDir.delete()==1:
    domainDir.mkdir()
    print 'Successfully created a new Directory'
  else:
    print 'Could not create new directory, dir already exists'
    stopExecution("cannot create a new directory") 
debug()
dsname="myJDBCDataSource"
adminServerName="medrec-adminServer"
domainName="WABTestDomain"
_url="t3://localhost:8001"
uname="weblogic"
pwd="weblogic"
startNewServer(adminServerName,domainName,_url,domainDir=domainDir.getPath(),
block="true")
connect(uname, pwd, _url)
edit()
startEdit()
